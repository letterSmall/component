

    
    
        jQuery(function() {
            var $module = jQuery('#m-1570091707070').children('.module');
            if(jQuery().gfYoutube) {
                $module.gfYoutube();
            }
        });
    